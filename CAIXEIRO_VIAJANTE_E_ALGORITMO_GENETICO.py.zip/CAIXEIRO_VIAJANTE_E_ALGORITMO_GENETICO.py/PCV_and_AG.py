import numpy as np
import random

# Definir uma semente para reprodutibilidade nos experimentos
np.random.seed(42)

# Matriz de distâncias entre 21 cidades (instância do problema do Caixeiro Viajante)
# Cada elemento representa a distância entre as cidades i e j.
cidades = np.array([
    # Matriz 21x21 representando as distâncias (simétrica)
    [0, 19, 17, 34, 7, 20, 10, 17, 28, 15, 23, 29, 23, 29, 21, 20, 9, 16, 21, 13, 12],
    # ... matriz truncada por brevidade ...
])

# Função para calcular a distância total de uma rota
# A rota é uma lista de índices representando a ordem em que as cidades são visitadas.
def calcular_distancia(cidades, rota):
    distancia = 0
    # Itera sobre pares consecutivos de cidades na rota
    for i in range(len(rota) - 1):
        distancia += cidades[rota[i]][rota[i + 1]]  # Soma a distância entre as cidades adjacentes
    # Soma a distância da última cidade para a cidade inicial (rota fechada)
    distancia += cidades[rota[-1]][rota[0]]
    return distancia

# Inicializar uma população de rotas
# Cada indivíduo na população é uma permutação aleatória das cidades
def inicializar_populacao(n_cidades, tamanho_populacao):
    return [random.sample(range(n_cidades), n_cidades) for _ in range(tamanho_populacao)]

# Seleção por torneio
# Escolhe o melhor indivíduo de um grupo aleatório de `k` indivíduos
def selecionar_pais(populacao, fitness, k=3):
    torneio = random.sample(list(zip(populacao, fitness)), k)  # Seleciona `k` indivíduos aleatórios
    torneio.sort(key=lambda x: x[1])  # Ordena pelo valor de fitness (menor é melhor)
    return torneio[0][0]  # Retorna o indivíduo com melhor fitness

# Cruzamento (Order Crossover - OX)
# Combina dois pais para gerar um filho
def cruzamento(pai1, pai2):
    # Escolhe dois pontos aleatórios para o cruzamento
    start, end = sorted(random.sample(range(len(pai1)), 2))
    filho = [-1] * len(pai1)  # Inicializa o filho com valores "vazios" (-1)
    filho[start:end] = pai1[start:end]  # Copia o segmento do pai1
    # Preenche o restante com os genes do pai2 que ainda não estão no filho
    preenchimento = [gene for gene in pai2 if gene not in filho]
    pos = 0
    for i in range(len(filho)):
        if filho[i] == -1:
            filho[i] = preenchimento[pos]
            pos += 1
    return filho

# Mutação por troca de dois elementos
# Troca a posição de dois genes em um indivíduo
def mutacao(individuo):
    i, j = random.sample(range(len(individuo)), 2)  # Seleciona dois índices aleatórios
    individuo[i], individuo[j] = individuo[j], individuo[i]  # Troca os elementos
    return individuo

# Algoritmo Genético para resolver o problema do Caixeiro Viajante
def algoritmo_genetico(cidades, n_geracoes, tamanho_populacao, taxa_mutacao):
    n_cidades = len(cidades)  # Número de cidades (dimensão do problema)
    populacao = inicializar_populacao(n_cidades, tamanho_populacao)  # Gera a população inicial
    
    # Loop principal do algoritmo genético
    for _ in range(n_geracoes):
        # Calcula o fitness de cada indivíduo (menor distância é melhor)
        fitness = [calcular_distancia(cidades, rota) for rota in populacao]
        nova_populacao = []  # Inicializa a nova geração
        
        # Gera a nova geração
        for _ in range(tamanho_populacao):
            pai1 = selecionar_pais(populacao, fitness)  # Seleciona um pai
            pai2 = selecionar_pais(populacao, fitness)  # Seleciona outro pai
            filho = cruzamento(pai1, pai2)  # Realiza o cruzamento para gerar um filho
            
            # Aplica mutação com uma probabilidade definida
            if random.random() < taxa_mutacao:
                filho = mutacao(filho)
            
            nova_populacao.append(filho)  # Adiciona o filho à nova população
        
        populacao = nova_populacao  # Substitui a população pela nova geração
    
    # Após todas as gerações, encontra o melhor indivíduo na população
    melhor_rota = min(populacao, key=lambda x: calcular_distancia(cidades, x))
    return melhor_rota, calcular_distancia(cidades, melhor_rota)

# Executar o Algoritmo Genético
melhor_rota, distancia = algoritmo_genetico(
    cidades, 
    n_geracoes=480,         # Número de gerações
    tamanho_populacao=910,  # Tamanho da população
    taxa_mutacao=0.9        # Taxa de mutação
)

# Exibe os resultados
print("Melhor rota encontrada:", melhor_rota)
print("Distância da melhor rota:", distancia)
